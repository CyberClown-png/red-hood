One-Click VXAceTranslator Patcher by JoSmiHnTh
Updated as of 11/3/2024

-HOW TO USE-

BEFORE YOU BEGIN: You must have the latest version of the raw Japanese game! If you try to patch an outdated version, the compilation process will fail!
You might also want to rename the Paradox folder as well into something that doesn't contain Japanese characters. While this isn't a necessary step for everyone, some users don't have Japanese locale installed on their PC--which leads to patching errors when command line can't read Japanese file paths properly.

1: Unpack the contents of this .zip package into your Japanese Paradox folder (where Game.exe is located). You will be asked if you want to replace the files in the Graphics folder; click yes (this translates some image text and most importantly ensures icons in-game aren't messed up after translation)
2: Go into the One-Click Patcher folder and place all of the translated scripts obtained from the Bitbucket repository into the Translated Files folder.
3: After placing all of the scripts into Translated Files, run Start Patcher.bat.
4: Just be patient as it goes throught the process of decrypting the game data archive and compiling all of the translated scripts into the extracted data.
*Note that it will hang for about two minutes or more on Map 002, as well as Map/Data/Maps 001, 193, and 287; don't panic, this is normal due to the fact this these are overworld maps, which are utterly massive and loaded with events, causing the patcher to take time. It will eventually finish compiling it and speed through the rest of the maps.
5: Once the Patcher reaches Weapons.rvdata2, it will automatically close--at this point, the game should be translated. Go back to the game folder and run Game.exe. You should now be playing a translated game!
*If you have Parts 1 and 2 of the game, you can "merge" them into Part 3 by copying over the contents of the Pictures folder in Graphics to the same location of your Part 3 graphics folder.
^This is VERY important if you want to access H-scenes and BFs from the previous chapters without experiencing black screens and possibly game crashes!

-COMMON ISSUES-

"The patcher closes as soon as I open it!"
You probably don't have Japanese locale installed on your PC, which in turn is messing with command line's attempt to path to your game.
Properly installing JP locale is one solution, but a simpler one is to just rename the もんむす・くえすと！RPG終章体験版 folder into something that doesn't have Japanese text. Then the patcher shouldn't encounter any startup issues.

"Galda is invisible on the world map!"
You likely imported decrypted graphics from Parts 1+2 before running the patcher, don't do this.
Galda's overworld spritesheet was added to a preexisting set of character sprites in Part 3.
The patcher will only decrypt files that aren't already in the Graphics folders, and skip over anything that's already there.
The only files you should be importing from Parts 1+2 are the images in the Pictures folder.

"The game crashes when I attempt to BF someone!"
ToroToro, for whatever reason, removed the checks to prevent the player from engaging with Part 1/2 BFs, but didn't include the graphics for them, which causes the game to crash from loading a nonexistent image.
Make sure you've imported all of the images from both Parts 1 and 2 of Monster Girl Quest: Paradox RPG before accepting any BF challenges.